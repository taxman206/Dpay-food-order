
<!DOCTYPE html>
<html>
<head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #7A7A7A;
}
       header {
  background-color:#16DED1;
  text-align: center;
  padding-top: 10px;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .search-container {
  float: right;
    
}

.topnav input[type=text] {
  padding: 5px;
  margin-top: 15px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 0px 0px;
    height: 45px;
  margin-top: 10px;
  margin-bottom: 7px;
  margin-right: 2px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 10%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
     h1 {
      padding: 10px;
        }
     header {
  background-color:#f1f1f1;
  text-align: center;
  padding-top: 10px;
}
       .navbar {
      margin-bottom: 50px;
      
    }
}
         
</style>
</head>

      <header>
    <div class="K1DIV">
  <div class="KamaHeader text-center">
    <h1>Kebab King</h1>      
    <p>Kings of Kebab</p>
  </div>
</div>
      
    

<div class="topnav">
  <a href="index.php">Home</a>
  <a href="kebab.php">Main</a>
  <a href="kebab-combos.php">Combos</a>
  <a href="kebab-drinks.php">Drinks</a>
  <a href="shoppingcart-kebab.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a>
  <div class="search-container">
    <form class="headerkebab.php" method="post">
      <input type="text" placeholder="search.." name="search">
      <button type="submit" class="btn btn-primary mb-2">Search</button>
    </form>   
      </div>
</div>
         
              
 
         
    </header>
    
    <body>
        
        
        <div style="margin:20px; " class="container-fluid">
            <div class="row">
                <div class="col-md-8">
    <?php
    
if (isset($_POST["search"])){
$searchq=$_POST["search"];
    
$query="SELECT* FROM tbl_product WHERE prodname LIKE '%$searchq%'";

$results=mysqli_query($con, $query);

    
if(mysqli_num_rows($results)>0){
while($row=mysqli_fetch_array($results)){
    $id=$row["id"];
    $prodname=$row["prodname"];
    $prodinfo=$row["prodinfo"];
    $prodprice=$row["prodprice"];
    $prodimg=$row["prodimg"];
    
   
    echo"     
         <div class='col-sm-4'>
        <div class='panel panel-primary'>
        <div style='border:2px solid #333;background-color:#f1f1f1; width:200px; height:350px; padding:35px; align='center'>
        <img src=img src='$prodimg' class='img-thumbnail' style='width:250px; height:120px;' >
    <h4 class='text-info'>$prodname</h4>
    <h4 class='text-danger'>$prodinfo</h4>
            <h4 class='text-danger'>$prodprice</h4>
    <button style='float:right;' class=btn btn-info btn btn-xs add_product>Add to cart</button>
    
    </div>
    </div>

    </div>
    ";
}
}
}
?>
                </div></div></div>
        
    </body>
</html>


