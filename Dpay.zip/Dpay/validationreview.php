<?php


session_start();

$con=mysqli_connect('localhost','root','');

mysqli_select_db($con, 'userregistration'); //select which database wanna use

$name =$_POST['user'];
$email =$_POST ['email'];
$comment =$_POST['comment'];


$s= "select *from userreview where email= '$email'";


$result=mysqli_query($con,$s);

$num=mysqli_num_rows($result);
if ($num==1){
    echo "Email already taken";
}
else{
    $_SESSION['name']=$name;
    $_SESSION['email']=$email;
    $_SESSION['comment']=$comment;
    
    $reg="insert into userreview(name,email,comment) values('$name','$email','$comment')";
    mysqli_query($con,$reg);
    header('location:ordersuccesful.php');
}
    ?>
