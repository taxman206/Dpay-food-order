<?php

session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Home</title>
  <meta charset="utf-8">
  <head>
  <meta name="description" content="Online food ordering">
  <meta name="keywords" content="food pick up, pizza,burgers,steak,lunch,dinner">
  <meta name="author" content="Mthabisi Junior Nyawose">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        
    .topnav {
  overflow: hidden;
  background-color: #7A7A7A;
        
}

        .header {
  background-color: #16DED1;
  padding: 20px;
  text-align: center;
}
        

        
        .topnav a {
  float: left;
  display: block;
  font-size: 24px;
    color:black;
  text-align: center;
  text-decoration: none;
}


   
 
    </style>
</head>
<body>

<div class="header">
    <h1>Restuarants Near You</h1>
    </div>
    
    <div class="topnav">  
       <ul class="nav navbar-nav navbar-left">
       <li><a href="#">DPAY</a></li>
       
        </ul></div>
    <br/>
        <div class="container">    
  <div class="row">
    <div class="col-sm-4">
      <div class="panel panel-primary">
          <div class="panel-heading">Kama Fried Chicken</div>
          <div class="panel-body"><a href="friedchicken.php"><img src="friedchickens.jpg" class="img-responsive" style="width:100%" alt="Image"></a></div>
        <div class="panel-footer">Pick Up</div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-danger">
        <div class="panel-heading">Burger Lab</div>
          <div class="panel-body"><a href="burgerlab.php"><img src="cartoon.gif"  class="img-responsive" style="width:100%" alt="Image"></a></div>
        <div class="panel-footer">Pick Up</div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-success">
        <div class="panel-heading">Sway Dine In</div>
          <div class="panel-body"><a href="swaydinein.php"><img src="familypack.jpg" class="img-responsive" style="width:100% " alt="Image"></a></div>
        <div class="panel-footer">Pick Up</div>
      </div>
    </div>
  </div>
</div><br>

<div class="container">    
  <div class="row">
    <div class="col-sm-4">
      <div class="panel panel-success">
        <div class="panel-heading">Smash Burgers</div>
          <div class="panel-body"><a href="smashburgers.php"><img src="smashburgers.jpg" class="img-responsive" style="width:100%" alt="Image"></a></div>
        <div class="panel-footer">Pick Up</div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-primary">
        <div class="panel-heading">Malibu</div>
          <div class="panel-body"><a href="malibu.php"><img src="malibuimg.jpg" class="img-responsive" style="width:100%" alt="Image"></a></div>
        <div class="panel-footer">Pick Up</div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-danger">
        <div class="panel-heading">Kebab King</div>
          <div class="panel-body"><a href="kebab.php"><img src="kebab.jpg" class="img-responsive" style="width:100%" alt="Image"></a></div>
        <div class="panel-footer">Pick Up</div>
      </div>
    </div>
  </div>
</div><br><br>

    

</body>
    
    <footer> 
       <?php
    include "footer.php";
        ?>
    </footer>
</html>
