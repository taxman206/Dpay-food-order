<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
.footer {
  background-color: #16DED1;
  padding: 5px;
  text-align: center;
    margin-top: 100px;
}
        .fa {
  padding: 10px;
  font-size: 30px;
  width: 50px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
}

.fa:hover {
    opacity: 0.7;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
}
        
    </style>
    </head>
    
    
   <footer>
       
    <div class="footer">
  <h1>DPAY</h1>
 <a href="https://www.facebook.com/" class="fa fa-facebook"></a>
<a href="https://twitter.com/?lang=en-au" class="fa fa-twitter"></a>
  <p>Copyright &copy; 2020 Dpay.com</p>
</div>
    </footer>