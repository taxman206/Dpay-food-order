<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
              header {
  background-color:#f1f1f1;
  text-align: center;
  padding-top: 10px;
}
       .navbar {
      margin-bottom: 60px;
      
    }
     
      h1 {
      padding: 10px;
        ;}
       </style>
</head>
    
    <header>
    <div class="K1DIV">
  <div class="KamaHeader text-center">
    <h1>Kamas Fried Chicken</h1>      
    <p>Fried chicken Crispy</p>
  </div>
</div>

	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#DpayNavBar">
    <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">DPAY</a>
    </div>
      
      
      <div class="collapse navbar-collapse" id="DpayNavBar">
      <ul class="nav navbar-nav">
        <li classf="active"><a href="index.php">Home</a></li>
            <li><a href="friedchicken.php">Fried Chicken</a></li>
          <li><a href="friedwings.php">Chicken Wings</a></li>
            <li><a href="combodeals.php">Fried Chicken Deals</a></li>
            <li><a href="drinks.php">Drinks</a></li>
            <li><a href="extras.php">Extras</a></li>
      </ul>     <ul class="nav navbar-nav navbar-right">
       
        <li><a href="shoppingcart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
      </ul>
        
    </div>
      
  </div>
</nav>
    
         
    </header>
    
    
    