<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        .header {
  background-color: #f1f1f1;
  padding: 20px;
  text-align: center;
}
        .topnav {
  overflow: hidden;
  background-color: #333;
}

/* Style the topnav links */
.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}
    </style>
    </head>
    <body>

        <div class="header">
  <h1>DPAY</h1>
  <p>Register Account</p>
</div>

<div class="topnav">
    <a href="logout.php">HOME</a>
   <a href="testingpersonal.php">Personal</a>
  
  
</div>
    </body>