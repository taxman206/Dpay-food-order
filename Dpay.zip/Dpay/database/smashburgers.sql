-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2020 at 04:06 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smashburgers`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_prodcombo`
--

CREATE TABLE `tbl_prodcombo` (
  `id` int(250) NOT NULL,
  `prodname` text NOT NULL,
  `prodinfo` varchar(50) NOT NULL,
  `prodprice` int(10) NOT NULL,
  `prodimg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_prodcombo`
--

INSERT INTO `tbl_prodcombo` (`id`, `prodname`, `prodinfo`, `prodprice`, `prodimg`) VALUES
(1, 'Meal Combo 1', 'Beef Burger+fries', 20, 'images/mealcombo1burgerlab.jpeg'),
(2, 'Meal Combo 2', 'Chicken Burger+ fries + 500ml Drink', 23, 'images/combomeal2burgerlab.jpg'),
(3, 'Meal Combo 3', 'Double beef burger+ fries+ 500ml drink', 25, 'images/mealcombo4burgerlab.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_proddrink`
--

CREATE TABLE `tbl_proddrink` (
  `id` int(250) NOT NULL,
  `prodname` text NOT NULL,
  `prodinfo` varchar(50) NOT NULL,
  `prodprice` int(10) NOT NULL,
  `prodimg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_proddrink`
--

INSERT INTO `tbl_proddrink` (`id`, `prodname`, `prodinfo`, `prodprice`, `prodimg`) VALUES
(1, 'Strawberry Milkshake', '500 ml ', 5, 'images/strawberrymilkshake.jpg'),
(2, 'Coca Cola', '500ml', 5, 'images/coke.jpg'),
(3, 'Sir Juice', '500ml  Apple', 5, 'images/sirjuiceapple.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(250) NOT NULL,
  `prodname` text NOT NULL,
  `prodinfo` varchar(50) NOT NULL,
  `prodprice` int(10) NOT NULL,
  `prodimg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `prodname`, `prodinfo`, `prodprice`, `prodimg`) VALUES
(1, 'Mercury', 'Beef Burger', 12, 'images/beefburger.jpg'),
(2, 'Venice', 'Chicken Burger, cheese', 13, 'images/chickenburger.jpg'),
(3, 'Earth', 'Lettuce beef burger, cheese', 15, 'images/lettuceburger.jpg'),
(4, 'Mars', 'Double Beef burger, cheese', 18, 'images/doublebeefburger.jpg'),
(5, 'Jupiter', 'Double chicken burger, cheese', 15, 'images/doublechickenburger.jpg'),
(6, 'Saturn', 'Triple burger, cheese, bacon', 23, 'images/triplebeefburger.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_prodcombo`
--
ALTER TABLE `tbl_prodcombo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_proddrink`
--
ALTER TABLE `tbl_proddrink`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_prodcombo`
--
ALTER TABLE `tbl_prodcombo`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_proddrink`
--
ALTER TABLE `tbl_proddrink`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
