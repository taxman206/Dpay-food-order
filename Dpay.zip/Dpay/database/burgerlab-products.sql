-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2020 at 04:05 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `burgerlab-products`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_prodcombo`
--

CREATE TABLE `tbl_prodcombo` (
  `id` int(250) NOT NULL,
  `prodname` varchar(50) NOT NULL,
  `prodinfo` text NOT NULL,
  `prodprice` int(10) NOT NULL,
  `prodimg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_prodcombo`
--

INSERT INTO `tbl_prodcombo` (`id`, `prodname`, `prodinfo`, `prodprice`, `prodimg`) VALUES
(1, 'Meal Combo 1', 'Beef Burger + Fries+ 500ml Drink', 20, 'images/mealcombo1burgerlab.jpeg'),
(2, 'Meal Combo 2', 'Chicken Burger + Fries+ 500 ml Drink', 20, 'images/combomeal2burgerlab.jpg'),
(3, 'Meal Combo 3', 'Lamb burger+ fries+500ml drink', 20, 'images/mealcombo3burgerlab.jpg'),
(4, 'Meal Combo 4', 'Double Beef burger + Fries+ 500ml Drink', 25, 'images/mealcombo4burgerlab.jpg'),
(5, 'Meal Combo 5', 'Double chicken Burger + fries+ 500ml Drink', 25, 'images/mealcombo2burgerlab.jpg'),
(6, 'Meal Combo 6', 'Lamb Burger+ Fries + 500ml Drink', 20, 'images/mealcombo6burgerlab.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_proddrink`
--

CREATE TABLE `tbl_proddrink` (
  `id` int(250) NOT NULL,
  `prodname` varchar(50) NOT NULL,
  `prodinfo` text NOT NULL,
  `prodprice` int(10) NOT NULL,
  `prodimg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_proddrink`
--

INSERT INTO `tbl_proddrink` (`id`, `prodname`, `prodinfo`, `prodprice`, `prodimg`) VALUES
(50, 'Coke', 'Coca Cola 500 ml', 5, 'images/coke.jpg'),
(51, 'Fanta', 'Fanta Orange 500ml', 5, 'images/fanta.jpg'),
(52, 'Oros juice', 'Orange Oros Juice', 4, 'images/oros.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(250) NOT NULL,
  `prodname` text NOT NULL,
  `prodinfo` varchar(50) NOT NULL,
  `prodprice` int(11) NOT NULL,
  `prodimg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `prodname`, `prodinfo`, `prodprice`, `prodimg`) VALUES
(1, 'Beef Jock Burger', 'Two beef patty, cheese', 15, 'images/cartoon.gif'),
(2, 'Beef Burger', 'Beef Patty with Cheese', 10, 'images/beefburger.jpg'),
(3, 'Boy Scout Beef', 'Two beef patty, cheese', 15, 'images/doublebeefburger.jpg'),
(4, 'Lamb Burger', 'Lamb Patty, cheese, ', 12, 'images/lambburger.jpg'),
(5, 'Chicken Burger', 'chicken patty, cheese', 10, 'images/chickenburger.jpg'),
(6, 'Double Chicken Burger', 'Two chicken patty, cheese', 15, 'images/doublechickenburger.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_prodcombo`
--
ALTER TABLE `tbl_prodcombo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_proddrink`
--
ALTER TABLE `tbl_proddrink`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_prodcombo`
--
ALTER TABLE `tbl_prodcombo`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_proddrink`
--
ALTER TABLE `tbl_proddrink`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
