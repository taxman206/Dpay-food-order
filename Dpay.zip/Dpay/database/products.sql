-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2020 at 04:06 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `products`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_prodcombo`
--

CREATE TABLE `tbl_prodcombo` (
  `id` int(11) NOT NULL,
  `prodname` varchar(20) NOT NULL,
  `prodinfo` varchar(40) NOT NULL,
  `prodprice` int(11) NOT NULL,
  `prodimg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_prodcombo`
--

INSERT INTO `tbl_prodcombo` (`id`, `prodname`, `prodinfo`, `prodprice`, `prodimg`) VALUES
(19, 'Meal Combo 1', 'Fried Chicken+Drink', 25, 'images/combo1.jpg'),
(20, 'Meal Combo 2', '24 wings+3 drink', 34, 'images/combo2.jpg'),
(21, 'Meal Combo 3', '12 wings+Fries', 25, 'images/combo2.jpg'),
(22, 'Double Trouble', 'Whole Fried Chicken+12 Wings', 38, 'images/chickenandwings.jpg'),
(23, 'Meal Combo 4', '24 Chicken Wings+Original Half Chicken', 50, 'images/familypack.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_proddrink`
--

CREATE TABLE `tbl_proddrink` (
  `id` int(255) NOT NULL,
  `prodname` text NOT NULL,
  `prodinfo` varchar(50) NOT NULL,
  `prodprice` int(4) NOT NULL,
  `prodimg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_proddrink`
--

INSERT INTO `tbl_proddrink` (`id`, `prodname`, `prodinfo`, `prodprice`, `prodimg`) VALUES
(28, 'Coke', '500ml ', 5, 'images/coke.jpg'),
(29, 'Sprite', '500ml ', 5, 'images/sprite.jpg'),
(30, 'Fanta Orange', '500 ml', 5, 'images/fantaorange.jpg\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_prodextra`
--

CREATE TABLE `tbl_prodextra` (
  `id` int(20) NOT NULL,
  `prodname` text NOT NULL,
  `prodinfo` varchar(30) NOT NULL,
  `prodprice` int(30) NOT NULL,
  `prodimg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_prodextra`
--

INSERT INTO `tbl_prodextra` (`id`, `prodname`, `prodinfo`, `prodprice`, `prodimg`) VALUES
(38, 'Fries', 'Freshly Salted Fries', 6, 'images/fries.jpg'),
(39, 'Coleslaw', 'Medium Coleslaw', 4, 'images/coleslaw.jpg'),
(40, 'Garlic Bread', 'Oven Baked Garlic Bread', 6, 'images/garlicbread.jpg\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(11) NOT NULL,
  `prodname` text NOT NULL,
  `prodinfo` varchar(100) NOT NULL,
  `prodprice` int(10) NOT NULL,
  `prodimg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `prodname`, `prodinfo`, `prodprice`, `prodimg`) VALUES
(1, 'Sweet and Sour \r\n', '8 pieces', 16, 'images/friedchicken.jpg'),
(2, 'Soy Korean Fried', '8 pieces', 22, 'images/soy.jpg'),
(3, 'Snow cheese', '8 pieces', 21, 'images/snow-cheese-chicken.jpg'),
(4, 'sweet chilli', '8 piece', 22, 'images/sweetchilli.jpg'),
(5, 'spicy fried', '8 piece', 23, 'images/spicychicken.jpeg'),
(6, 'soy garlic', '8 pieces', 20, 'images/soychicken.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_prodwings`
--

CREATE TABLE `tbl_prodwings` (
  `id` int(11) NOT NULL,
  `prodname` varchar(30) NOT NULL,
  `prodinfo` varchar(50) NOT NULL,
  `prodprice` int(10) NOT NULL,
  `prodimg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_prodwings`
--

INSERT INTO `tbl_prodwings` (`id`, `prodname`, `prodinfo`, `prodprice`, `prodimg`) VALUES
(10, 'Dunked wings', 'Dunked in special sauce (12 pcs)', 16, 'images/dunked.jpg'),
(11, 'Sweet and sour Wings', '12 pcs', 18, 'images/wings%20oldskool.jpg'),
(12, 'Deep Fried Wings', '(12 pcs)', 15, 'images/wings.jpg'),
(13, 'Chipotle Wings', '12 pcs ', 18, 'images/chiptolewings.jpg'),
(14, 'Barbecue Wings', '12 pcs', 18, 'images/barbecuewings.jpg'),
(15, 'Lemon and Herb Wings', '12 pcs ', 15, 'images/lemonandherbwings.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_prodcombo`
--
ALTER TABLE `tbl_prodcombo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_proddrink`
--
ALTER TABLE `tbl_proddrink`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_prodextra`
--
ALTER TABLE `tbl_prodextra`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_prodwings`
--
ALTER TABLE `tbl_prodwings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_prodcombo`
--
ALTER TABLE `tbl_prodcombo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tbl_proddrink`
--
ALTER TABLE `tbl_proddrink`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tbl_prodextra`
--
ALTER TABLE `tbl_prodextra`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_prodwings`
--
ALTER TABLE `tbl_prodwings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
