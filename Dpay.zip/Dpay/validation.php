<?php


session_start();

$con=mysqli_connect('localhost','root','');

mysqli_select_db($con, 'userregistration'); //select which database wanna use


$email =$_POST ['email'];
$pass =$_POST['password'];

$s= "SELECT password,name FROM usertable where email= '".$email."'LIMIT 1";


$result=mysqli_query($con,$s);

If(mysqli_num_rows($result)>0){
    $row=mysqli_fetch_array($result);
    if(password_verify($pass,$row["password"]))  header('location:ordersuccesful.php');
}
else{
    header('location:login.php');

}

    ?>
