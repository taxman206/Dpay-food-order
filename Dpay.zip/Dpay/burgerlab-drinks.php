<!DOCTYPE html>
<html>
<head>
    <title>Drinks</title>
        <meta charset="utf-8">
   <meta name="description" content="Burgerlab ">
  <meta name="keywords" content="food, burgers,chicken burgers,drinks,combos,">
  <meta name="author" content="Mthabisi Junior Nyawose">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        
    </head>
    
<?php
session_start();


$con=mysqli_connect('localhost','root','');
mysqli_select_db($con, 'burgerlab-products');

if(isset($_POST["add_to_cart"]))
{
	if(isset($_SESSION["shopping_cart"]))
	{
		$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
		if(!in_array($_GET["id"], $item_array_id))
		{
			$count = count($_SESSION["shopping_cart"]);
			$item_array = array(
				'item_id'			=>	$_GET["id"],
				'item_prodname'			=>	$_POST["hidden_prodname"],
				'item_prodprice'		=>	$_POST["hidden_prodprice"],
				'item_quantity'		=>	$_POST["quantity"]
			);
			$_SESSION["shopping_cart"][$count] = $item_array;
		}
		else
		{
			echo '<script>alert("Item Already Added")</script>';
		}
	}
	else
	{
		$item_array = array(
			'item_id'			=>	$_GET["id"],
			'item_prodname'			=>	$_POST["hidden_prodname"],
			'item_prodprice'		=>	$_POST["hidden_prodprice"],
			'item_quantity'		=>	$_POST["quantity"]
		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "delete")
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)
		{
			if($values["item_id"] == $_GET["id"])
			{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>alert("Item Removed")</script>';
				echo '<script>window.location="shoppingcart.php"</script>';
			}
		}
	}
}

?>
    <body>
        
         <?php
    include "headerburgerlab.php";
        ?>
    
    <br/>
        
        
    
    
        
        <h1 class="text-center">Drinks</h1>
        <div class="container"  style="width:700px; " >       
            
 
        <?php
        $query= "SELECT * FROM tbl_proddrink ORDER BY id ";
        $result= mysqli_query($con, $query);
        if (mysqli_num_rows($result)>0)
        {
            while($row=mysqli_fetch_array($result))
            {
                ?>
         
            
    <div class="col-sm-4">
        
      
            <form method="post" action="burgerlab-drinks.php? actionadd&id=<?php echo $row["id"]; ?>">
        <div class="panel panel-primary">
             <div style="border:2px solid #333;background-color:#f1f1f1; width:200px; height:350px; padding:35px;" align="center" >
               <img src="<?php echo $row["prodimg"];?>" class="img-thumbnail"  style="width:250px; height:120px;"  >
        <h4 class="text-info"><?php echo $row["prodname"];?></h4>
            <h4 class="text-danger"><?php echo $row["prodinfo"];?></h4><h4 class="text-danger">$<?php echo $row["prodprice"];?></h4>
                 
            <input type="text" name="quantity" class="form-control" value="1"/>
                 <input type="hidden" name="hidden_prodname" value="<?php echo $row["prodname"]; ?>" />

						<input type="hidden" name="hidden_prodprice" value="<?php echo $row["prodprice"]; ?>" />
             <input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />
                      
                </div>
                </div>
        </form>
        </div>
    
        <?php
            }
        }
        ?>        
        
        </div>
    <br/>
    
       
    
    </body>
    <footer> <?php
    include "footer.php";
        ?>
    </footer>
</html>
        
        
        
       